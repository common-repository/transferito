<?php

echo 'This is a sample php file';
